<?php

/**
 * Page template
 *
 */

include("./head.inc"); 

echo $page->body;

include("./foot.inc"); 

