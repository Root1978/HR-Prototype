<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Classic", 
	'summary' => "This was the default site profile from ProcessWire versions 2.0 through 2.4. While now a little older in appearance, it is a great starting point for learning about ProcessWire.", 
	'screenshot' => "screenshot.jpg"
	);
