<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Blank", 
	'summary' => "This profile includes only the bare minimum pages, fields and templates, giving you essentially a blank slate. ", 
	'screenshot' => ""
	);
